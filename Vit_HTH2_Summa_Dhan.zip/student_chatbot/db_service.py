from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, EmailStr
import sqlite3, hashlib, os
from datetime import datetime

DB_PATH = "app.db"

# --- DB setup ---
conn = sqlite3.connect(DB_PATH, check_same_thread=False)
cur = conn.cursor()
cur.execute("""
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    email TEXT UNIQUE,
    password_hash TEXT,
    created_at TEXT DEFAULT (datetime('now'))
)
""")
cur.execute("""
CREATE TABLE IF NOT EXISTS quiz_results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    score INTEGER,
    submitted_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY(user_id) REFERENCES users(id)
)
""")
conn.commit()

# --- helpers ---
def hash_password(password: str) -> str:
    # Simple hash for demo. For production use bcrypt/argon2.
    salt = os.getenv("PW_SALT", "demo_salt_change_me")
    return hashlib.sha256((salt + password).encode("utf-8")).hexdigest()

def get_user_by_username(username: str):
    cur.execute("SELECT id, username, email, password_hash FROM users WHERE username=?", (username,))
    row = cur.fetchone()
    if not row:
        return None
    return {"id": row[0], "username": row[1], "email": row[2], "password_hash": row[3]}

# --- FastAPI app ---
app = FastAPI(title="DB Service (Users & Quiz Results)")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],   # change to your frontend origin in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- models ---
class SignupBody(BaseModel):
    username: str
    email: EmailStr
    password: str

class LoginBody(BaseModel):
    username: str
    password: str

class SubmitMarksBody(BaseModel):
    user_id: int
    score: int

# --- endpoints ---
@app.post("/signup")
def signup(body: SignupBody):
    if get_user_by_username(body.username):
        raise HTTPException(status_code=400, detail="Username already exists.")
    password_hash = hash_password(body.password)
    try:
        cur.execute(
            "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)",
            (body.username, body.email, password_hash)
        )
        conn.commit()
        user_id = cur.lastrowid
        return {"ok": True, "user_id": user_id}
    except sqlite3.IntegrityError as e:
        # likely duplicate email
        raise HTTPException(status_code=400, detail="Email already exists.")

@app.post("/login")
def login(body: LoginBody):
    user = get_user_by_username(body.username)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid username or password.")
    if user["password_hash"] != hash_password(body.password):
        raise HTTPException(status_code=401, detail="Invalid username or password.")
    return {"ok": True, "user_id": user["id"], "username": user["username"]}

@app.post("/submit_marks")
def submit_marks(body: SubmitMarksBody):
    # ensure user exists
    cur.execute("SELECT id FROM users WHERE id=?", (body.user_id,))
    if not cur.fetchone():
        raise HTTPException(status_code=400, detail="User not found.")
    cur.execute(
        "INSERT INTO quiz_results (user_id, score, submitted_at) VALUES (?, ?, ?)",
        (body.user_id, body.score, datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    )
    conn.commit()
    return {"ok": True}

@app.get("/my_marks/{user_id}")
def my_marks(user_id: int):
    cur.execute("SELECT id, score, submitted_at FROM quiz_results WHERE user_id=? ORDER BY id DESC", (user_id,))
    rows = cur.fetchall()
    return {"ok": True, "results": [{"id": r[0], "score": r[1], "submitted_at": r[2]} for r in rows]}
