// filepath: c:\Users\Dhinesh\Documents\project\script.js
// Simple SPA logic and quiz engine

const LS = { USER: "ai_tutor_user", STATS: "ai_tutor_stats" };
const state = {
  user: null,
  selectedDomain: null,
  selectedSubject: null,
  quiz: { currentIndex: 0, difficulty: 3, score: 0, answers: [], total: 5 },
  stats: { quizzesTaken: 0, totalCorrect: 0, totalAsked: 0 },
};

const DB = {
  domains: [
    { name: "Math", subjects: ["Algebra", "Geometry", "Arithmetic"] },
    { name: "Science", subjects: ["Physics", "Chemistry", "Biology"] },
    { name: "English", subjects: ["Grammar", "Comprehension"] },
    // NEW DOMAINS
    { name: "Art & Culture", subjects: ["Painting", "Music", "Dance"] },
    { name: "Health & Fitness", subjects: ["Nutrition", "Exercise Science", "Mental Health"] },
    { name: "General Knowledge", subjects: ["Current Affairs", "World Facts", "Sports"] }
  ],
  questions: {
    // ===================== MATH =====================
    Algebra: {
      1: [
        {
          q: "A café sells a pastry for ₹50 and offers ₹5 off. What is the price after discount?",
          opts: ["₹45", "₹50", "₹55", "₹40"], answer: 0
        },
        {
          q: "If x + 2 = 7 describes the cost (x) of a pen after adding ₹2 tax, what is x?",
          opts: ["3", "4", "5", "7"], answer: 2
        }
      ],
      2: [
        {
          q: "A mechanic charges a fixed ₹200 plus ₹50 per hour. Which expression gives the total for h hours?",
          opts: ["200h + 50", "50h + 200", "200 + 50", "250h"], answer: 1
        },
        {
          q: "Solve for x: 2x − 6 = 10 (think of balancing a bill with a ₹6 coupon).",
          opts: ["x=2", "x=6", "x=8", "x=10"], answer: 2
        }
      ],
      3: [
        {
          q: "A rectangle has length (x+3) and width (x−1). Which expands its area?",
          opts: ["x^2 + 2x − 3", "x^2 + 4x − 3", "x^2 + 3x − 1", "x^2 + 2x + 3"], answer: 1
        },
        {
          q: "Factor the revenue model x^2 + 5x + 6 (break-even at roots).",
          opts: ["(x+2)(x+3)", "(x+1)(x+6)", "(x+3)(x+6)", "(x+2)(x+6)"], answer: 0
        }
      ],
      4: [
        {
          q: "You model profit by y = 3x^2 − 12x + 9. What is the vertex x-value (turning point for profit)?",
          opts: ["x = 2", "x = 3", "x = 4", "x = 6"], answer: 0
        },
        {
          q: "Solve for x (inventory threshold): 3(x − 2) = 2(x + 4).",
          opts: ["x=2", "x=6", "x=8", "x=10"], answer: 1
        }
      ],
      5: [
        {
          q: "A projectile’s height is h(t)=−5t^2+20t+15. When does it reach maximum height?",
          opts: ["t=1 s", "t=2 s", "t=3 s", "t=4 s"], answer: 1
        },
        {
          q: "Solve x^2 − 5x + 6 = 0 (critical production levels).",
          opts: ["x=2 or 3", "x=−2 or −3", "x=1 or 6", "No real roots"], answer: 0
        }
      ]
    },
    Geometry: {
      1: [
        {
          q: "A smartphone screen is a rectangle 6 cm by 3 cm. What’s the area?",
          opts: ["9 cm²", "12 cm²", "18 cm²", "24 cm²"], answer: 2
        },
        {
          q: "A square tile has side 4 cm. Perimeter?",
          opts: ["8 cm", "12 cm", "16 cm", "20 cm"], answer: 2
        }
      ],
      2: [
        {
          q: "A map uses 1 cm : 5 km. Two cities are 7 cm apart on the map. Real distance?",
          opts: ["12 km", "25 km", "35 km", "70 km"], answer: 2
        },
        {
          q: "A right triangle has legs 6 and 8. Hypotenuse length?",
          opts: ["10", "12", "14", "16"], answer: 0
        }
      ],
      3: [
        {
          q: "A circular garden has radius 7 m. Using π≈22/7, area is roughly:",
          opts: ["44 m²", "154 m²", "308 m²", "484 m²"], answer: 1
        },
        {
          q: "A 5×3 photo is enlarged with the same ratio to width 10. New height?",
          opts: ["4.5", "5", "6", "7.5"], answer: 2
        }
      ],
      4: [
        {
          q: "A square’s diagonal is 10 cm. Side length?",
          opts: ["5", "5√2", "10", "10√2"], answer: 1
        },
        {
          q: "Regular hexagon interior angle measure?",
          opts: ["90°", "108°", "120°", "135°"], answer: 2
        }
      ],
      5: [
        {
          q: "A cylinder with radius 3 cm and height 10 cm has volume (πr²h) equal to:",
          opts: ["90π", "30π", "60π", "120π"], answer: 0
        },
        {
          q: "Two similar triangles have sides in ratio 3:5. Their areas are in ratio:",
          opts: ["3:5", "5:3", "9:25", "25:9"], answer: 2
        }
      ]
    },
    Arithmetic: {
      1: [
        {
          q: "You buy 3 apples at ₹20 each. Total cost?",
          opts: ["₹20", "₹40", "₹60", "₹80"], answer: 2
        },
        {
          q: "A bill is ₹250 and you pay with ₹500. Change back?",
          opts: ["₹100", "₹150", "₹200", "₹250"], answer: 2
        }
      ],
      2: [
        {
          q: "Compute 15% of ₹200 (a restaurant tip).",
          opts: ["₹20", "₹25", "₹30", "₹35"], answer: 2
        },
        {
          q: "A train travels 120 km in 2 hours. Average speed?",
          opts: ["40 km/h", "50 km/h", "60 km/h", "80 km/h"], answer: 2
        }
      ],
      3: [
        {
          q: "A 20% discount on a ₹1,500 jacket equals:",
          opts: ["₹150", "₹200", "₹300", "₹350"], answer: 2
        },
        {
          q: "Find the average of 12, 18, 30.",
          opts: ["18", "20", "22", "24"], answer: 1
        }
      ],
      4: [
        {
          q: "Simple interest on ₹5,000 at 6% per year for 3 years is:",
          opts: ["₹600", "₹750", "₹900", "₹1,200"], answer: 2
        },
        {
          q: "HCF of 36 and 48 is:",
          opts: ["6", "8", "12", "24"], answer: 2
        }
      ],
      5: [
        {
          q: "Two numbers are in ratio 2:3 and sum to 250. The larger number is:",
          opts: ["100", "120", "150", "180"], answer: 2
        },
        {
          q: "A car’s value depreciates 10% yearly. If it’s ₹10,00,000 now, value after 1 year:",
          opts: ["₹8,00,000", "₹9,00,000", "₹9,50,000", "₹10,00,000"], answer: 1
        }
      ]
    },

    // ===================== SCIENCE =====================
    Physics: {
      1: [
        {
          q: "A cyclist covers 600 m in 60 s. Average speed?",
          opts: ["5 m/s", "8 m/s", "10 m/s", "12 m/s"], answer: 0
        },
        {
          q: "Which unit measures force in daily physics problems?",
          opts: ["Joule", "Watt", "Newton", "Pascal"], answer: 2
        }
      ],
      2: [
        {
          q: "A box is pushed with 20 N across 2 m. Work done?",
          opts: ["10 J", "20 J", "40 J", "400 J"], answer: 2
        },
        {
          q: "Near Earth’s surface, g is approximately:",
          opts: ["8 m/s²", "9.8 m/s²", "12 m/s²", "1 m/s²"], answer: 1
        }
      ],
      3: [
        {
          q: "A 2 kg object moving at 3 m/s has momentum (p=mv) equal to:",
          opts: ["2 kg·m/s", "3 kg·m/s", "5 kg·m/s", "6 kg·m/s"], answer: 3
        },
        {
          q: "Pressure in fluids is measured in:",
          opts: ["J", "W", "Pa", "N"], answer: 2
        }
      ],
      4: [
        {
          q: "In a circuit, doubling current while keeping resistance same does what to voltage (Ohm’s law)?",
          opts: ["Halves it", "No change", "Doubles it", "Triples it"], answer: 2
        },
        {
          q: "A 60 W bulb uses 60 J per ___ of energy.",
          opts: ["second", "minute", "hour", "day"], answer: 0
        }
      ],
      5: [
        {
          q: "A car of mass 1,000 kg moving at 20 m/s has kinetic energy (½mv²) of:",
          opts: ["2×10^4 J", "2×10^5 J", "4×10^5 J", "2×10^6 J"], answer: 1
        },
        {
          q: "A transformer steps voltage up by factor 10. Input 24 V. Ideal output (ignoring losses):",
          opts: ["2.4 V", "24 V", "240 V", "2,400 V"], answer: 2
        }
      ]
    },
    Chemistry: {
      1: [
        {
          q: "Table salt used in cooking has formula:",
          opts: ["NaCl", "KCl", "HCl", "NaOH"], answer: 0
        },
        {
          q: "Neutral solutions have pH closest to:",
          opts: ["1", "7", "9", "14"], answer: 1
        }
      ],
      2: [
        {
          q: "Vinegar is dilute acetic acid. It tastes:",
          opts: ["Sweet", "Bitter", "Sour", "Salty"], answer: 2
        },
        {
          q: "Which turns red litmus paper blue?",
          opts: ["Acid", "Base", "Salt", "Water"], answer: 1
        }
      ],
      3: [
        {
          q: "One mole contains approximately:",
          opts: ["6.02×10^20", "6.02×10^22", "6.02×10^23", "6.02×10^25"], answer: 2
        },
        {
          q: "Molar mass of H2O is about:",
          opts: ["16 g/mol", "18 g/mol", "28 g/mol", "32 g/mol"], answer: 1
        }
      ],
      4: [
        {
          q: "A catalyst typically:",
          opts: ["Increases activation energy", "Decreases activation energy", "Stops reaction", "Changes equilibrium constant"], answer: 1
        },
        {
          q: "pH < 7 indicates the solution is:",
          opts: ["Acidic", "Neutral", "Basic", "Saline"], answer: 0
        }
      ],
      5: [
        {
          q: "In redox reactions, oxidation involves:",
          opts: ["Gain of electrons", "Loss of electrons", "Sharing equally", "No electron transfer"], answer: 1
        },
        {
          q: "Strong acid commonly used in labs is:",
          opts: ["H2CO3", "HCl", "NH3", "CH3COOH"], answer: 1
        }
      ]
    },
    Biology: {
      1: [
        {
          q: "The ‘powerhouse’ of the cell is the:",
          opts: ["Nucleus", "Ribosome", "Mitochondrion", "Lysosome"], answer: 2
        },
        {
          q: "Plants produce oxygen during:",
          opts: ["Respiration", "Photosynthesis", "Fermentation", "Transpiration"], answer: 1
        }
      ],
      2: [
        {
          q: "White blood cells primarily help with:",
          opts: ["Oxygen transport", "Clotting", "Immunity", "Digestion"], answer: 2
        },
        {
          q: "Xylem mainly transports:",
          opts: ["Food", "Water and minerals", "Hormones", "Waste"], answer: 1
        }
      ],
      3: [
        {
          q: "Humans typically have how many heart chambers?",
          opts: ["2", "3", "4", "5"], answer: 2
        },
        {
          q: "Genetic information is stored primarily in:",
          opts: ["Proteins", "Carbohydrates", "DNA", "Lipids"], answer: 2
        }
      ],
      4: [
        {
          q: "Which organ produces bile to aid fat digestion?",
          opts: ["Stomach", "Liver", "Pancreas", "Small intestine"], answer: 1
        },
        {
          q: "During vigorous exercise, muscles may form:",
          opts: ["Glucose", "Lactic acid", "Glycogen", "Urea"], answer: 1
        }
      ],
      5: [
        {
          q: "Meiosis is directly responsible for producing:",
          opts: ["Somatic cells", "Gametes", "Platelets", "Neurons"], answer: 1
        },
        {
          q: "Which cells are central to adaptive immunity?",
          opts: ["RBCs", "Macrophages only", "B and T lymphocytes", "Platelets"], answer: 2
        }
      ]
    },

    // ===================== ENGLISH =====================
    Grammar: {
      1: [
        {
          q: "Choose the correct sentence for a daily routine:",
          opts: ["He go to school.", "He goes to school.", "He going to school.", "He gone to school."], answer: 1
        },
        {
          q: "Pick the correct article: I saw ___ orange umbrella.",
          opts: ["a", "an", "the", "no article"], answer: 1
        }
      ],
      2: [
        {
          q: "Identify the adverb: She spoke softly to calm the child.",
          opts: ["She", "spoke", "softly", "child"], answer: 2
        },
        {
          q: "Find the preposition: The keys are under the mat.",
          opts: ["The", "keys", "under", "mat"], answer: 2
        }
      ],
      3: [
        {
          q: "Pick the sentence with correct subject–verb agreement:",
          opts: ["Neither of the options are ideal.", "Neither of the options is ideal.", "Neither of the options be ideal.", "Neither option were ideal."], answer: 1
        },
        {
          q: "Select the comparative form of ‘efficient’:",
          opts: ["more efficient", "most efficient", "efficienter", "efficiency"], answer: 0
        }
      ],
      4: [
        {
          q: "Convert to passive: The manager approved the budget.",
          opts: ["The budget was approved by the manager.", "The budget approved the manager.", "The manager was approved by the budget.", "Approved the budget manager."], answer: 0
        },
        {
          q: "Reported speech: He said, “I have finished the report.”",
          opts: ["He said he has finished the report.", "He said he had finished the report.", "He says he had finished the report.", "He said he finished the report now."], answer: 1
        }
      ],
      5: [
        {
          q: "Choose the best conditional: If I had known earlier, I ___ helped.",
          opts: ["will have", "would have", "have", "had"], answer: 1
        },
        {
          q: "Identify the clause type: “Because the data were inconsistent, …”",
          opts: ["Main clause", "Co-ordinate clause", "Subordinate adverbial clause", "Noun clause"], answer: 2
        }
      ]
    },
    Comprehension: {
      1: [
        {
          q: "Short text: “The museum opens at 10 AM and closes at 6 PM.” When does it open?",
          opts: ["8 AM", "9 AM", "10 AM", "11 AM"], answer: 2
        },
        {
          q: "Short text: “The bakery sells fresh bread daily.” What is sold?",
          opts: ["Cakes", "Bread", "Pastries only", "Coffee"], answer: 1
        }
      ],
      2: [
        {
          q: "Text: “Rainfall has increased in the region this month.” The main idea is:",
          opts: ["It’s been drier", "Rainfall decreased", "Rainfall increased", "No change"], answer: 2
        },
        {
          q: "Word-in-context: “She was elated after the results.” ‘Elated’ means:",
          opts: ["Worried", "Exhausted", "Very happy", "Confused"], answer: 2
        }
      ],
      3: [
        {
          q: "Text: “Jordan runs faster than Lee.” Who is faster?",
          opts: ["Jordan", "Lee", "Same speed", "Not stated"], answer: 0
        },
        {
          q: "Text: “Water boils at 100°C under standard pressure.” Boiling point is:",
          opts: ["0°C", "50°C", "100°C", "200°C"], answer: 2
        }
      ],
      4: [
        {
          q: "Context clue: “The arid plateau received only sparse rainfall.” ‘Arid’ is closest to:",
          opts: ["Wet", "Dry", "Cold", "Windy"], answer: 1
        },
        {
          q: "Inference: “He glanced at the clock every minute.” He is likely:",
          opts: ["Relaxed", "Unaware of time", "In a hurry", "Sleeping"], answer: 2
        }
      ],
      5: [
        {
          q: "Evaluating sources: For medical facts, the most credible is:",
          opts: ["Anonymous blog", "Peer-reviewed journal", "Random tweet", "Viral video"], answer: 1
        },
        {
          q: "Critical reading: A text with strong one-sided language likely has:",
          opts: ["No bias", "Balanced tone", "Author bias", "Only data"], answer: 2
        }
      ]
    },

    // ===================== ART & CULTURE =====================
    Painting: {
      1: [
        {
          q: "Acrylic paint is commonly thinned with:",
          opts: ["Water", "Turpentine", "Kerosene", "Alcohol"], answer: 0
        },
        {
          q: "The term ‘palette’ in painting usually refers to:",
          opts: ["Brush type", "Color board", "Canvas size", "Display wall"], answer: 1
        }
      ],
      2: [
        {
          q: "Which surface is most typical for oil painting practice?",
          opts: ["Canvas", "Glass", "Plastic", "Rubber"], answer: 0
        },
        {
          q: "Underpainting helps artists to:",
          opts: ["Finalize frame", "Plan values and composition", "Seal the painting", "Sign the artwork"], answer: 1
        }
      ],
      3: [
        {
          q: "Impasto refers to paint applied:",
          opts: ["Very thinly", "Very thickly", "Only as a wash", "Only with airbrush"], answer: 1
        },
        {
          q: "Complementary colors (e.g., blue & orange) are opposite on the color wheel and often used to:",
          opts: ["Mute contrast", "Enhance contrast", "Remove shadows", "Flatten forms"], answer: 1
        }
      ],
      4: [
        {
          q: "Varnishing a finished oil painting primarily helps to:",
          opts: ["Change canvas size", "Protect and unify gloss", "Remove pigment", "Speed drying"], answer: 1
        },
        {
          q: "A grisaille is an underpainting executed mostly in:",
          opts: ["Greys", "Yellows", "Reds", "Blues"], answer: 0
        }
      ],
      5: [
        {
          q: "Chiaroscuro is best described as a technique focusing on:",
          opts: ["Bright color harmonies", "Line variation only", "Strong light–dark contrasts", "Flat shapes"], answer: 2
        },
        {
          q: "Gesso on a canvas is used to:",
          opts: ["Seal and prime the surface", "Stretch the canvas", "Frame the painting", "Create varnish"], answer: 0
        }
      ]
    },
    Music: {
      1: [
        {
          q: "Tempo in a song refers to its:",
          opts: ["Loudness", "Speed", "Pitch", "Timbre"], answer: 1
        },
        {
          q: "The number of beats per bar in common time is:",
          opts: ["2", "3", "4", "6"], answer: 2
        }
      ],
      2: [
        {
          q: "A melody accompanied by simple chords is often described as:",
          opts: ["Monophonic", "Homophonic", "Polyphonic", "Atonal"], answer: 1
        },
        {
          q: "Dynamics marked ‘p’ and ‘f’ indicate:",
          opts: ["Slow/Fast", "Soft/Loud", "Low/High", "Short/Long"], answer: 1
        }
      ],
      3: [
        {
          q: "A key signature with two sharps (F# and C#) indicates which major key?",
          opts: ["D major", "G major", "A major", "E major"], answer: 0
        },
        {
          q: "Syncopation accents typically fall on:",
          opts: ["Strong beats only", "Weak/off-beats", "Downbeat only", "First beat only"], answer: 1
        }
      ],
      4: [
        {
          q: "A cadence that ends on V (dominant) and sounds unfinished is a:",
          opts: ["Perfect", "Plagal", "Deceptive", "Half cadence"], answer: 3
        },
        {
          q: "In orchestration, doubling a melody an octave higher usually:",
          opts: ["Darkens timbre", "Lightens/brightens texture", "Removes harmony", "Slows tempo"], answer: 1
        }
      ],
      5: [
        {
          q: "Twelve-tone technique (dodecaphony) is associated most with:",
          opts: ["Classical era", "Baroque era", "Serialism/20th-century modernism", "Romantic era"], answer: 2
        },
        {
          q: "A modulation from C major to A major moves by:",
          opts: ["Minor 3rd", "Major 3rd", "Perfect 4th", "Tritone"], answer: 1
        }
      ]
    },
    Dance: {
      1: [
        {
          q: "A warm-up before dancing primarily reduces risk of:",
          opts: ["Dehydration", "Injury", "Fatigue", "Soreness next day"], answer: 1
        },
        {
          q: "Basic timing for a simple waltz pattern is counted:",
          opts: ["1-2", "1-2-3", "1-2-3-4", "1-2-3-4-5-6"], answer: 1
        }
      ],
      2: [
        {
          q: "In hip-hop, ‘isolation’ focuses on moving:",
          opts: ["Entire body", "Only head", "Specific body parts independently", "Only legs"], answer: 2
        },
        {
          q: "Spotting during turns helps dancers to:",
          opts: ["Jump higher", "Avoid dizziness and improve balance", "Kick further", "Stretch hamstrings"], answer: 1
        }
      ],
      3: [
        {
          q: "A plié in ballet primarily trains:",
          opts: ["Foot articulation", "Knee bending & alignment", "Back flexibility", "Arm positions"], answer: 1
        },
        {
          q: "In contemporary choreography, floor work emphasizes:",
          opts: ["Leaps only", "Use of gravity, rolls, transitions", "Turns only", "Lifts only"], answer: 1
        }
      ],
      4: [
        {
          q: "Counterbalance in partnering relies on:",
          opts: ["Speed only", "Equal and opposite forces", "Height difference", "Music tempo"], answer: 1
        },
        {
          q: "Cue-to-cue in stage rehearsal refers to:",
          opts: ["Practicing only music", "Running transitions between cues", "Full run without pauses", "Costume fitting"], answer: 1
        }
      ],
      5: [
        {
          q: "Laban Movement Analysis categorizes movement using factors like:",
          opts: ["Only tempo", "Effort, shape, space, body", "Only space", "Only shape"], answer: 1
        },
        {
          q: "A canon in group dance is when performers:",
          opts: ["Move identically in unison", "Perform the same phrase starting at different times", "Freestyle", "Swap roles"], answer: 1
        }
      ]
    },

    // ===================== HEALTH & FITNESS =====================
    Nutrition: {
      1: [
        {
          q: "A balanced plate at lunch should ideally include:",
          opts: ["Only carbs", "Carbs + protein + vegetables", "Only protein", "Only fruit"], answer: 1
        },
        {
          q: "Hydration tip for a normal day: drink water when you feel:",
          opts: ["Thirsty", "Full", "Sleepy", "Stressed"], answer: 0
        }
      ],
      2: [
        {
          q: "Dietary fiber helps primarily with:",
          opts: ["Vision", "Digestion & satiety", "Muscle growth", "Bone density"], answer: 1
        },
        {
          q: "Which is a complete protein source?",
          opts: ["Rice", "Beans", "Eggs", "Bread"], answer: 2
        }
      ],
      3: [
        {
          q: "Glycemic index (GI) compares foods based on their effect on:",
          opts: ["Blood pressure", "Blood sugar", "Cholesterol", "Hydration"], answer: 1
        },
        {
          q: "A person aiming for fat loss often benefits from a protein intake around:",
          opts: ["0.2 g/kg", "0.8 g/kg", "1.2–2.0 g/kg", "3.0 g/kg"], answer: 2
        }
      ],
      4: [
        {
          q: "Omega-3 fatty acids are abundant in:",
          opts: ["White rice", "Leafy greens", "Fatty fish & flax", "Butter"], answer: 2
        },
        {
          q: "Micronutrient critical for oxygen transport in blood is:",
          opts: ["Calcium", "Iron", "Potassium", "Vitamin C"], answer: 1
        }
      ],
      5: [
        {
          q: "For endurance athletes, carb loading before an event mainly increases:",
          opts: ["Body water retention only", "Muscle glycogen stores", "Protein synthesis", "Hemoglobin"], answer: 1
        },
        {
          q: "A registered dietitian’s primary role is to:",
          opts: ["Prescribe medicine", "Diagnose illness", "Provide medical nutrition therapy & guidance", "Perform surgery"], answer: 2
        }
      ]
    },
    "Exercise Science": {
      1: [
        {
          q: "A brisk 30-minute walk most closely fits which intensity?",
          opts: ["Very light", "Light", "Moderate", "Vigorous"], answer: 2
        },
        {
          q: "A warm-up increases:",
          opts: ["Injury risk", "Joint stiffness", "Muscle temperature & blood flow", "Dehydration"], answer: 2
        }
      ],
      2: [
        {
          q: "The FITT principle helps plan workouts. ‘F’ stands for:",
          opts: ["Force", "Frequency", "Form", "Flexibility"], answer: 1
        },
        {
          q: "DOMS typically appears:",
          opts: ["Immediately", "12–24 h later", "48–72 h later", "Never"], answer: 2
        }
      ],
      3: [
        {
          q: "Progressive overload means you should gradually increase:",
          opts: ["Only rest time", "Training stimulus (e.g., weight, volume, intensity)", "Gym visits only", "Music tempo"], answer: 1
        },
        {
          q: "During steady-state cardio, energy is primarily supplied by:",
          opts: ["Anaerobic alactic system", "Anaerobic lactic system", "Aerobic system", "Phosphagen only"], answer: 2
        }
      ],
      4: [
        {
          q: "Compound lifts (e.g., squats) are effective because they:",
          opts: ["Work one small muscle", "Burn no calories", "Engage multiple joints & muscles", "Are unsafe by default"], answer: 2
        },
        {
          q: "VO₂ max refers to the maximum:",
          opts: ["Speed", "Power", "Oxygen uptake/utilization", "Heartbeats"], answer: 2
        }
      ],
      5: [
        {
          q: "Periodization in training is best described as:",
          opts: ["Random workouts", "Long-term planned variation in volume/intensity", "Only heavy lifting", "Only stretching"], answer: 1
        },
        {
          q: "The stretch-shortening cycle enhances:",
          opts: ["Endurance only", "Maximal strength only", "Explosive power (plyometrics)", "Flexibility only"], answer: 2
        }
      ]
    },
    "Mental Health": {
      1: [
        {
          q: "A simple daily habit that supports mental well-being:",
          opts: ["Skipping sleep", "Short walks & sunlight exposure", "Constant multitasking", "Overeating"], answer: 1
        },
        {
          q: "Deep breathing exercises primarily help to lower:",
          opts: ["Heart rate & stress", "Muscle mass", "Body fat", "Vision strain"], answer: 0
        }
      ],
      2: [
        {
          q: "Good sleep hygiene includes:",
          opts: ["Late caffeine", "Irregular bedtime", "Consistent schedule", "Bright screens in bed"], answer: 2
        },
        {
          q: "Journaling can help by:",
          opts: ["Worsening rumination", "Structuring thoughts & emotions", "Erasing memories", "Replacing therapy"], answer: 1
        }
      ],
      3: [
        {
          q: "Mindfulness practice commonly involves:",
          opts: ["Suppressing all thoughts", "Non-judgmental awareness of present moment", "Analyzing the past only", "Planning the future only"], answer: 1
        },
        {
          q: "Social support often buffers against:",
          opts: ["Resilience", "Stress & burnout", "Creativity", "Hydration"], answer: 1
        }
      ],
      4: [
        {
          q: "CBT (Cognitive Behavioral Therapy) focuses on changing:",
          opts: ["Genetics", "Automatic thoughts & behaviors", "Only diet", "Only sleep"], answer: 1
        },
        {
          q: "A common sign of chronic stress is:",
          opts: ["Improved immunity", "Better sleep", "Irritability & fatigue", "Lower blood pressure"], answer: 2
        }
      ],
      5: [
        {
          q: "Seeking professional help is most urgent when someone:",
          opts: ["Feels bored", "Shows persistent hopelessness or self-harm thoughts", "Skips a meal", "Has mild nervousness"], answer: 1
        },
        {
          q: "Evidence-based self-care plans should be:",
          opts: ["One-size-fits-all", "Personalized & reviewed", "Random tips", "Only supplements"], answer: 1
        }
      ]
    },

    // ===================== GENERAL KNOWLEDGE =====================
    "Current Affairs": {
      1: [
        {
          q: "A budget speech typically outlines a government’s:",
          opts: ["Sports schedule", "Spending & revenue plan", "Monsoon forecast", "Election dates"], answer: 1
        },
        {
          q: "A central bank raising policy rates usually aims to reduce:",
          opts: ["Inflationary pressure", "Exports", "Employment", "Bank savings"], answer: 0
        }
      ],
      2: [
        {
          q: "An MoU signed between two countries often signals:",
          opts: ["Final law", "Intent to cooperate", "Court order", "Breaking ties"], answer: 1
        },
        {
          q: "A government capital expenditure project most likely funds:",
          opts: ["Daily office snacks", "Salaries", "Infrastructure like roads & bridges", "Travel vouchers"], answer: 2
        }
      ],
      3: [
        {
          q: "Trade deficits occur when a country’s:",
          opts: ["Exports > Imports", "Imports > Exports", "Exports = Imports", "No trade"], answer: 1
        },
        {
          q: "A climate summit agreement generally targets:",
          opts: ["Higher emissions", "Lower emissions & adaptation", "Banning all energy", "Only transport fuel"], answer: 1
        }
      ],
      4: [
        {
          q: "A sovereign green bond is used to finance:",
          opts: ["Any project", "Environment-friendly projects", "Defense imports", "Gold reserves"], answer: 1
        },
        {
          q: "When a country signs a free trade agreement (FTA), tariffs between partners generally:",
          opts: ["Increase", "Stay same", "Decrease or eliminate", "Become random"], answer: 2
        }
      ],
      5: [
        {
          q: "Digital public infrastructure (DPI) typically refers to interoperable systems for:",
          opts: ["Gaming", "Public digital services (payments, identity, data)", "Only social media", "Private messaging"], answer: 1
        },
        {
          q: "A ‘carbon market’ allows entities to:",
          opts: ["Trade emission allowances/credits", "Trade only oil", "Trade only coal", "Trade rainfall"], answer: 0
        }
      ]
    },
    "World Facts": {
      1: [
        {
          q: "The world’s largest ocean is the:",
          opts: ["Atlantic", "Indian", "Pacific", "Arctic"], answer: 2
        },
        {
          q: "The Sahara is a:",
          opts: ["Rainforest", "Desert", "Mountain range", "Lake"], answer: 1
        }
      ],
      2: [
        {
          q: "Mount Everest lies in the ___ range.",
          opts: ["Andes", "Himalayas", "Alps", "Rockies"], answer: 1
        },
        {
          q: "The Amazon River primarily flows through:",
          opts: ["Brazil", "India", "China", "South Africa"], answer: 0
        }
      ],
      3: [
        {
          q: "The European Union’s currency used by many members is the:",
          opts: ["Pound", "Dollar", "Euro", "Franc"], answer: 2
        },
        {
          q: "Australia lies in which hemisphere(s)?",
          opts: ["Northern only", "Southern only", "Both Northern & Eastern", "Western only"], answer: 2
        }
      ],
      4: [
        {
          q: "GDP per capita is best described as a measure of:",
          opts: ["Total population", "Average economic output per person", "Total exports", "National debt"], answer: 1
        },
        {
          q: "The Suez Canal connects the Mediterranean Sea to the:",
          opts: ["Black Sea", "Red Sea", "Arabian Sea", "Caspian Sea"], answer: 1
        }
      ],
      5: [
        {
          q: "The UN Security Council has how many permanent members?",
          opts: ["3", "4", "5", "6"], answer: 2
        },
        {
          q: "The G7 is primarily a group of:",
          opts: ["Developing economies", "Major advanced economies", "Oil exporters", "Island nations"], answer: 1
        }
      ]
    },
    Sports: {
      1: [
        {
          q: "In football (soccer), a goal is worth:",
          opts: ["1 point", "2 points", "3 points", "6 points"], answer: 0
        },
        {
          q: "In cricket, a boundary that touches the ground before the rope scores:",
          opts: ["4 runs", "6 runs", "2 runs", "1 run"], answer: 0
        }
      ],
      2: [
        {
          q: "In basketball, a successful shot from beyond the arc is worth:",
          opts: ["1", "2", "3", "4"], answer: 2
        },
        {
          q: "In tennis, 40-40 is called:",
          opts: ["Advantage", "Deuce", "Love", "Break"], answer: 1
        }
      ],
      3: [
        {
          q: "In cricket, a bowler’s economy rate primarily measures:",
          opts: ["Wickets per over", "Runs conceded per over", "Strike rate", "Speed"], answer: 1
        },
        {
          q: "In football, ‘offside’ typically refers to an attacker being:",
          opts: ["Ahead of the ball only", "Ahead of the second-last defender at pass", "Behind the halfway line", "Inside the penalty area"], answer: 1
        }
      ],
      4: [
        {
          q: "In hockey, a ‘power play’ occurs when:",
          opts: ["Both teams have full strength", "A team has a player advantage due to a penalty", "Time-out", "Extra goalie"], answer: 1
        },
        {
          q: "In athletics, a 4×100 relay has how many baton exchanges?",
          opts: ["2", "3", "4", "5"], answer: 1
        }
      ],
      5: [
        {
          q: "In chess, the only piece that can ‘jump’ over other pieces is the:",
          opts: ["Bishop", "Rook", "Knight", "Queen"], answer: 2
        },
        {
          q: "In Formula 1, DRS is a system that primarily reduces:",
          opts: ["Engine power", "Drag on the rear wing", "Tyre wear", "Fuel usage"], answer: 1
        }
      ]
    }
  }
};

// DOM helpers
function id(x) { return document.getElementById(x); }
function qs(x) { return document.querySelector(x); }

// Screens
const loginScreen = id("login-screen");
const appScreen = id("app-screen");

// Login
const usernameInput = id("username");
const btnLogin = id("btn-login");
const btnGuest = id("btn-guest");
const welcomeName = id("welcome-name");
const btnLogout = id("btn-logout");

// Theme
const themeToggle = id("theme-toggle");
const themeToggle2 = id("theme-toggle-2");

// Domains & Subjects
const domainsGrid = id("domains-grid");
const selectedPath = id("selected-path");
const subjectList = id("subject-list");
const startQuizBtn = id("start-quiz");

// Quiz
const quizIntro = id("quiz-intro");
const quizRun = id("quiz-run");
const quizSummary = id("quiz-summary");
const quizArea = id("quiz-area");
const qIndex = id("q-index");
const qDifficulty = id("q-difficulty");
const questionText = id("question-text");
const optionsWrap = id("options");
const nextBtn = id("next-btn");
const skipBtn = id("skip-btn");
const scoreEl = id("score");
const finalScore = id("final-score");
const accuracyEl = id("accuracy");
const estLevel = id("est-level");
const suggestionsEl = id("suggestions");
const retryBtn = id("retry-btn");
const backToSubjects = id("back-to-subjects");
const progressFill = id("progress-fill");

// Chat & Progress
const chatWindow = id("chat-window");
const chatInput = id("chat-input");
const sendChat = id("send-chat");
const aiToggle = id("ai-toggle");
const totalQuizzesEl = id("total-quizzes");
const overallAccuracyEl = id("overall-accuracy");
const overallLevelEl = id("overall-level");

// SPA Navigation
function showLogin() {
  loginScreen?.classList.remove("hidden");
  loginScreen?.classList.add("active");
  appScreen?.classList.add("hidden");
  appScreen?.classList.remove("active");
}
function showApp() {
  loginScreen?.classList.add("hidden");
  loginScreen?.classList.remove("active");
  appScreen?.classList.remove("hidden");
  appScreen?.classList.add("active");
}

// Theme toggle
function toggleTheme() {
  document.body.classList.toggle("theme-dark");
}
themeToggle?.addEventListener("click", toggleTheme);
themeToggle2?.addEventListener("click", toggleTheme);

// Login logic
btnLogin?.addEventListener("click", () => {
  const name = usernameInput.value.trim() || "User";
  state.user = name;
  localStorage.setItem(LS.USER, name);
  welcomeName.textContent = `Hi, ${name}`;
  showApp();
  renderDomains();
  renderStats();
});
btnGuest?.addEventListener("click", () => {
  state.user = "Guest";
  welcomeName.textContent = `Hi, Guest`;
  showApp();
  renderDomains();
  renderStats();
});
btnLogout?.addEventListener("click", () => {
  showLogin();
  usernameInput.value = "";
});

// Domains rendering
function renderDomains() {
  domainsGrid.innerHTML = "";
  DB.domains.forEach(d => {
    const card = document.createElement("div");
    card.className = "domain-card";
    card.innerHTML = `<strong>${d.name}</strong><div class="muted small">${d.subjects.slice(0, 3).join(', ')}</div>`;
    card.addEventListener("click", () => selectDomain(d));
    domainsGrid.appendChild(card);
  });
  selectedPath.textContent = "None";
  subjectList.innerHTML = "";
  quizIntro.classList.remove("hidden");
  quizRun.classList.add("hidden");
  quizSummary.classList.add("hidden");
  startQuizBtn.disabled = true;
}

function selectDomain(domain) {
  state.selectedDomain = domain.name;
  selectedPath.textContent = `${domain.name} → None`;
  subjectList.innerHTML = "";
  domain.subjects.forEach(sub => {
    const btn = document.createElement("button");
    btn.className = "subject-btn";
    btn.textContent = sub;
    btn.addEventListener("click", () => selectSubject(domain, sub));
    subjectList.appendChild(btn);
  });
  quizIntro.classList.remove("hidden");
  quizRun.classList.add("hidden");
  quizSummary.classList.add("hidden");
  startQuizBtn.disabled = true;
}

function selectSubject(domain, subject) {
  state.selectedSubject = subject;
  selectedPath.textContent = `${domain.name} → ${subject}`;
  startQuizBtn.disabled = false;
  quizIntro.querySelector("p").textContent = `Ready to start the adaptive 5-question ${subject} quiz.`;
}

// Quiz logic
startQuizBtn?.addEventListener("click", startQuiz);
skipBtn?.addEventListener("click", handleSkip);
nextBtn?.addEventListener("click", handleNext);
retryBtn?.addEventListener("click", startQuiz);
backToSubjects?.addEventListener("click", () => {
  quizIntro.classList.remove("hidden");
  quizRun.classList.add("hidden");
  quizSummary.classList.add("hidden");
  startQuizBtn.disabled = false;
});

function resetQuiz() {
  state.quiz.currentIndex = 0;
  state.quiz.difficulty = 3;
  state.quiz.score = 0;
  state.quiz.answers = [];
  state.quiz.total = 5;
  nextBtn.disabled = true;
  scoreEl.textContent = "0";
  progressFill.style.width = "0%";
}

function pickQuestion() {
  const subject = state.selectedSubject;
  const pool = (DB.questions[subject] && DB.questions[subject][state.quiz.difficulty]) || [];
  if (pool.length === 0) {
    // Safety fallback (should not trigger now that all pools are filled):
    for (let d = 1; d <= 5; d++) {
      const p = (DB.questions[subject] && DB.questions[subject][d]) || [];
      if (p.length) { state.quiz.difficulty = d; return randomFromArray(p); }
    }
    return null;
  }
  return randomFromArray(pool);
}

function randomFromArray(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

function startQuiz() {
  if (!state.selectedSubject) { alert("Pick a subject first."); return; }
  resetQuiz();
  quizIntro.classList.add("hidden");
  quizRun.classList.remove("hidden");
  quizSummary.classList.add("hidden");
  renderQuestion();
}

function renderQuestion() {
  const q = pickQuestion();
  if (!q) { endQuiz(); return; }
  state.quiz.currentQuestion = q;
  qIndex.textContent = `Q ${state.quiz.currentIndex + 1} / ${state.quiz.total}`;
  qDifficulty.textContent = `Difficulty: ${state.quiz.difficulty}`;
  questionText.textContent = q.q;
  optionsWrap.innerHTML = "";
  q.opts.forEach((opt, idx) => {
    const btn = document.createElement("button");
    btn.className = "option-btn";
    btn.textContent = opt;
    btn.addEventListener("click", () => selectOption(btn, idx, q.answer));
    optionsWrap.appendChild(btn);
  });
  nextBtn.disabled = true;
  updateProgress();
}

function selectOption(button, idx, correctIdx) {
  Array.from(optionsWrap.children).forEach((btn, i) => {
    btn.classList.remove("correct", "wrong");
    if (i === correctIdx) btn.classList.add("correct");
    if (i === idx && idx !== correctIdx) btn.classList.add("wrong");
  });
  nextBtn.disabled = false;
  if (idx === correctIdx) state.quiz.score++;
  state.quiz.answers.push({ q: state.quiz.currentQuestion.q, chosen: idx, correct: idx === correctIdx, difficulty: state.quiz.difficulty });
  scoreEl.textContent = state.quiz.score;
}

function handleSkip() {
  state.quiz.answers.push({ q: state.quiz.currentQuestion.q, chosen: null, correct: false, difficulty: state.quiz.difficulty });
  state.quiz.difficulty = Math.max(1, state.quiz.difficulty - 1);
  proceedNext();
}

function handleNext() {
  const lastAnswer = state.quiz.answers[state.quiz.answers.length - 1];
  if (lastAnswer && lastAnswer.correct) {
    state.quiz.difficulty = Math.min(5, state.quiz.difficulty + 1);
  } else {
    state.quiz.difficulty = Math.max(1, state.quiz.difficulty - 1);
  }
  proceedNext();
}

function proceedNext() {
  state.quiz.currentIndex++;
  if (state.quiz.currentIndex >= state.quiz.total) {
    endQuiz();
  } else {
    renderQuestion();
  }
}

function endQuiz() {
  quizRun.classList.add("hidden");
  quizSummary.classList.remove("hidden");
  finalScore.textContent = state.quiz.score;
  const acc = Math.round((state.quiz.score / state.quiz.total) * 100);
  accuracyEl.textContent = `${acc}%`;
  estLevel.textContent = levelFromAccuracy(acc);
  suggestionsEl.innerHTML = "";
  generateSuggestions(acc, state.selectedSubject).forEach(s => {
    const li = document.createElement("li");
    li.textContent = s;
    suggestionsEl.appendChild(li);
  });
  state.stats.quizzesTaken += 1;
  state.stats.totalCorrect += state.quiz.score;
  state.stats.totalAsked += state.quiz.total;
  saveStats();
  renderStats();
}

function updateProgress() {
  const pct = (state.quiz.currentIndex / state.quiz.total) * 100;
  progressFill.style.width = `${pct}%`;
}

// Suggestions and levels
function levelFromAccuracy(acc) {
  if (acc >= 85) return "Expert";
  if (acc >= 65) return "Advanced";
  if (acc >= 45) return "Intermediate";
  if (acc >= 25) return "Beginner";
  return "Novice";
}

function generateSuggestions(acc, subject) {
  const out = [];
  if (acc >= 85) {
    out.push("Excellent — try harder timed sets and proofs.");
    out.push("Explore related topics and teach others to consolidate knowledge.");
  } else if (acc >= 65) {
    out.push("Great job! Try more advanced questions.");
    out.push("Review any mistakes and ask the AI tutor for help.");
  } else if (acc >= 45) {
    out.push("Keep practicing. Focus on topics you missed.");
    out.push("Ask the AI tutor for step-by-step explanations.");
  } else if (acc >= 25) {
    out.push("Review basics and practice daily.");
    out.push("Use the AI tutor for hints and explanations.");
  } else {
    out.push("Start with simple questions and build up.");
    out.push("Ask the AI tutor for step-by-step help.");
  }
  return out;
}

// Chat
sendChat?.addEventListener("click", handleChatSend);
chatInput?.addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleChatSend(); } });
aiToggle?.addEventListener("click", () => {
  appendChat("Rule-based AI enabled. Ask me about math, science, or English!", "ai");
});

function appendChat(text, who = 'ai') {
  const el = document.createElement("div");
  el.className = `chat-bubble ${who === 'user' ? 'user' : 'ai'}`;
  el.textContent = text;
  chatWindow.appendChild(el);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

async function handleChatSend() {
  const txt = chatInput.value.trim();
  if (!txt) return;

  appendChat(txt, 'user');
  chatInput.value = "";

  try {
    const res = await fetch("http://127.0.0.1:8000/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message: txt
      })
    });

    const data = await res.json();

    if (res.ok) {
      appendChat(data.answer, 'ai');
    } else {
      appendChat(data.detail || "Error from server", 'ai');
    }
  } catch (err) {
    appendChat("Unable to connect to server.", 'ai');
  }
}

// Stats
function saveStats() {
  localStorage.setItem(LS.STATS, JSON.stringify(state.stats));
}

function loadStats() {
  const s = localStorage.getItem(LS.STATS);
  if (s) state.stats = JSON.parse(s);
}

function renderStats() {
  totalQuizzesEl.textContent = state.stats.quizzesTaken;
  const acc = state.stats.totalAsked ? Math.round((state.stats.totalCorrect / state.stats.totalAsked) * 100) : 0;
  overallAccuracyEl.textContent = `${acc}%`;
  overallLevelEl.textContent = levelFromAccuracy(acc);
}

// On page load
(function init() {
  const savedUser = localStorage.getItem(LS.USER);
  loadStats();
  if (savedUser) {
    state.user = savedUser;
    welcomeName.textContent = `Hi, ${savedUser}`;
    showApp();
    renderDomains();
    renderStats();
  } else {
    showLogin();
  }
})();